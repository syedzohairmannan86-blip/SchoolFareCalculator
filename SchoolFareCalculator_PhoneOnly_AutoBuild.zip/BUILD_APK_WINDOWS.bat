@echo off
echo Open this folder in Android Studio and let Gradle sync.
echo Then use Build ^> Build APK(s).
pause
