# School Fare Calculator — Phone-Only APK Build

This project is prepared for building an APK from an Android phone using GitHub Actions.
You do NOT need Android Studio or a computer.

## Phone steps

1. Open GitHub in Chrome and sign in.
2. Create a NEW repository.
3. Upload the contents of this project into the repository. Upload the folders too, especially:
   - app
   - .github
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab.
6. Select **Build School Fare Calculator APK**.
7. Tap **Run workflow** if it has not already started.
8. Wait for the green check mark.
9. Open the completed workflow run.
10. Scroll to **Artifacts**.
11. Download `SchoolFareCalculator-debug-apk`.
12. Extract the downloaded ZIP and install `app-debug.apk`.

## Important

- This is a debug APK intended for personal installation/testing.
- The app stores daily fare records locally on the phone using WebView storage.
- Clearing the app's storage or uninstalling the app can erase saved records.
