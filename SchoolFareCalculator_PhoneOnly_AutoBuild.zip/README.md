# School Fare Calculator — Android Project

A native Android wrapper around the School Vehicle Fare Calculator.

## What it does
- Monthly calendar
- Select a school date
- Select the people who travelled
- Enter that day's total vehicle fare
- Automatically splits the fare among the selected people
- Monthly total for every person
- Add/remove people
- Records are stored locally by the WebView, so saved days remain after closing/reopening the app.

## Build the APK in Android Studio

1. Install Android Studio.
2. Open this project folder: `SchoolFareCalculatorAndroid`.
3. Let Android Studio download/sync the Gradle and Android dependencies.
4. Select **Build > Build APK(s)**.
5. The debug APK will normally be at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Copy that APK to your Android phone and install it.

For a signed release APK:
Build > Generate Signed Bundle / APK > APK.

## Important
The project is intentionally offline. The calculator does not require internet access after installation.
